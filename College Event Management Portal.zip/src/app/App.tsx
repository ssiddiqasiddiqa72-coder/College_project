import { useState, useMemo } from "react";
import { motion } from "motion/react";
import {
  Calendar, MapPin, Users, Clock, QrCode, Award, Search,
  Plus, Edit2, Trash2, Download, X, Check, Shield, LogOut,
  BarChart2, Menu, BookOpen, Star, Eye, Lock, ArrowRight,
  Image as ImageIcon,
} from "lucide-react";

// ── Types ──────────────────────────────────────────────────────────────────────

type EventCategory = "tech" | "cultural" | "sports" | "workshop" | "seminar" | "music";
type View = "events" | "gallery" | "tickets" | "certificates" | "admin";
type AdminTab = "dashboard" | "manage" | "registrations";

interface CollegeEvent {
  id: string;
  title: string;
  category: EventCategory;
  date: string;
  time: string;
  venue: string;
  description: string;
  capacity: number;
  registeredCount: number;
  image: string;
  organizer: string;
  tags: string[];
  featured?: boolean;
}

interface Registration {
  id: string;
  eventId: string;
  studentName: string;
  studentId: string;
  email: string;
  department: string;
  year: string;
  registeredAt: string;
  ticketCode: string;
}

interface GalleryPhoto {
  id: string;
  eventName: string;
  year: string;
  image: string;
  caption: string;
}

// ── Mock Data ──────────────────────────────────────────────────────────────────

const INITIAL_EVENTS: CollegeEvent[] = [
  {
    id: "evt-001",
    title: "TechFest 2025 — National Hackathon",
    category: "tech",
    date: "2025-02-15",
    time: "09:00",
    venue: "Main Auditorium, Block A",
    description: "Join 500+ developers, designers, and innovators for 36 hours of building, learning, and competing. Theme: AI for Social Good.",
    capacity: 500,
    registeredCount: 312,
    image: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&h=450&fit=crop&auto=format",
    organizer: "Computer Science Department",
    tags: ["hackathon", "coding", "AI", "prizes"],
    featured: true,
  },
  {
    id: "evt-002",
    title: "Annual Cultural Fest — Utsav 2025",
    category: "cultural",
    date: "2025-03-08",
    time: "17:00",
    venue: "Open Air Theatre",
    description: "A three-day festival celebrating art, music, dance, and drama. Performances, competitions, and food stalls from across the country.",
    capacity: 2000,
    registeredCount: 1456,
    image: "https://images.unsplash.com/photo-1470229722913-7c0e2dbbafd3?w=800&h=450&fit=crop&auto=format",
    organizer: "Student Council",
    tags: ["festival", "dance", "music", "food"],
    featured: true,
  },
  {
    id: "evt-003",
    title: "Inter-College Basketball Championship",
    category: "sports",
    date: "2025-02-22",
    time: "10:00",
    venue: "Sports Complex, Court 1",
    description: "24 teams from 12 colleges compete in a 3-day knockout tournament. Cheer for the home team and witness elite-level college basketball.",
    capacity: 800,
    registeredCount: 445,
    image: "https://images.unsplash.com/photo-1546519638-68e109498ffc?w=800&h=450&fit=crop&auto=format",
    organizer: "Sports Committee",
    tags: ["basketball", "championship", "sports"],
  },
  {
    id: "evt-004",
    title: "UI/UX Design Workshop — Figma to Production",
    category: "workshop",
    date: "2025-02-10",
    time: "14:00",
    venue: "Design Lab, Block C, Room 204",
    description: "A hands-on 6-hour workshop on professional design workflows. Learn Figma prototyping, design systems, and hand-off to development.",
    capacity: 60,
    registeredCount: 58,
    image: "https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=800&h=450&fit=crop&auto=format",
    organizer: "Design Club",
    tags: ["design", "figma", "ux", "hands-on"],
  },
  {
    id: "evt-005",
    title: "Dr. Priya Sharma — Guest Lecture on ML Ethics",
    category: "seminar",
    date: "2025-02-18",
    time: "11:00",
    venue: "Seminar Hall 2, Block B",
    description: "Renowned AI researcher Dr. Priya Sharma (MIT Media Lab) speaks on ethical frameworks in machine learning and their real-world implications.",
    capacity: 200,
    registeredCount: 187,
    image: "https://images.unsplash.com/photo-1558021211-6d1403321394?w=800&h=450&fit=crop&auto=format",
    organizer: "AI Research Cell",
    tags: ["ML", "ethics", "guest lecture", "AI"],
  },
  {
    id: "evt-006",
    title: "Campus Music Night — Live Bands",
    category: "music",
    date: "2025-03-01",
    time: "19:00",
    venue: "Amphitheatre, North Campus",
    description: "Six campus bands take the stage for a night of original compositions and covers. Indie, jazz, rock, and fusion. Free entry for registered attendees.",
    capacity: 1200,
    registeredCount: 723,
    image: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=800&h=450&fit=crop&auto=format",
    organizer: "Music Club",
    tags: ["music", "live", "bands", "night"],
  },
];

const GALLERY_PHOTOS: GalleryPhoto[] = [
  { id: "g1", eventName: "TechFest 2024", year: "2024", image: "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=600&h=420&fit=crop&auto=format", caption: "Hackathon winners presentation" },
  { id: "g2", eventName: "Utsav 2024", year: "2024", image: "https://images.unsplash.com/photo-1429962714451-bb934ecdc4ec?w=600&h=700&fit=crop&auto=format", caption: "Classical dance performance" },
  { id: "g3", eventName: "Sports Day 2024", year: "2024", image: "https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=600&h=380&fit=crop&auto=format", caption: "Track and field finals" },
  { id: "g4", eventName: "Convocation 2024", year: "2024", image: "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=600&h=500&fit=crop&auto=format", caption: "Graduation ceremony" },
  { id: "g5", eventName: "Design Summit 2024", year: "2024", image: "https://images.unsplash.com/photo-1557804506-669a67965ba0?w=600&h=450&fit=crop&auto=format", caption: "Workshop in progress" },
  { id: "g6", eventName: "Music Night 2024", year: "2024", image: "https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=600&h=380&fit=crop&auto=format", caption: "Campus band performing" },
  { id: "g7", eventName: "AI Summit 2024", year: "2024", image: "https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=600&h=550&fit=crop&auto=format", caption: "Robotics demonstration" },
  { id: "g8", eventName: "Cultural Fest 2024", year: "2024", image: "https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?w=600&h=400&fit=crop&auto=format", caption: "Food and culture stalls" },
];

const INITIAL_REGISTRATIONS: Registration[] = [
  {
    id: "reg-001",
    eventId: "evt-001",
    studentName: "Arjun Mehta",
    studentId: "CS21B1042",
    email: "arjun.mehta@nit.edu",
    department: "Computer Science",
    year: "3rd Year",
    registeredAt: "2025-01-20T10:30:00",
    ticketCode: "TF25-CS21B1042-A7K9",
  },
  {
    id: "reg-002",
    eventId: "evt-002",
    studentName: "Arjun Mehta",
    studentId: "CS21B1042",
    email: "arjun.mehta@nit.edu",
    department: "Computer Science",
    year: "3rd Year",
    registeredAt: "2025-01-25T14:15:00",
    ticketCode: "UT25-CS21B1042-M3P8",
  },
];

// ── Constants ──────────────────────────────────────────────────────────────────

const CAT_CFG: Record<EventCategory, { label: string; color: string; bg: string }> = {
  tech:      { label: "Tech",      color: "text-blue-400",   bg: "bg-blue-500/10 border-blue-500/20" },
  cultural:  { label: "Cultural",  color: "text-purple-400", bg: "bg-purple-500/10 border-purple-500/20" },
  sports:    { label: "Sports",    color: "text-emerald-400",bg: "bg-emerald-500/10 border-emerald-500/20" },
  workshop:  { label: "Workshop",  color: "text-amber-400",  bg: "bg-amber-500/10 border-amber-500/20" },
  seminar:   { label: "Seminar",   color: "text-cyan-400",   bg: "bg-cyan-500/10 border-cyan-500/20" },
  music:     { label: "Music",     color: "text-pink-400",   bg: "bg-pink-500/10 border-pink-500/20" },
};

const DEMO_STUDENT_ID = "CS21B1042";

// ── Helpers ────────────────────────────────────────────────────────────────────

function formatDate(d: string) {
  return new Date(d).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" });
}

function formatTime(t: string) {
  const [h, m] = t.split(":");
  const hr = parseInt(h);
  return `${hr > 12 ? hr - 12 : hr || 12}:${m} ${hr >= 12 ? "PM" : "AM"}`;
}

function genTicketCode(eventId: string, studentId: string) {
  const pfx = eventId.replace("evt-", "E").toUpperCase();
  const sfx = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `${pfx}-${studentId}-${sfx}`;
}

// ── QR Code SVG ────────────────────────────────────────────────────────────────

function QRCode({ value, size = 140 }: { value: string; size?: number }) {
  const GRID = 25;
  const pad = 1;
  const cell = size / (GRID + pad * 2);
  const off = pad * cell;

  const matrix = useMemo(() => {
    let seed = 0;
    for (let i = 0; i < value.length; i++) {
      seed = (((seed << 5) - seed) + value.charCodeAt(i)) | 0;
    }
    const rand = () => {
      seed = (seed * 1664525 + 1013904223) >>> 0;
      return (seed >>> 0) / 4294967296;
    };
    const g: boolean[][] = Array.from({ length: GRID }, () =>
      Array.from({ length: GRID }, () => rand() > 0.5)
    );
    const finder = (sr: number, sc: number) => {
      for (let r = 0; r < 7; r++) {
        for (let c = 0; c < 7; c++) {
          g[sr + r][sc + c] =
            r === 0 || r === 6 || c === 0 || c === 6 ||
            (r >= 2 && r <= 4 && c >= 2 && c <= 4);
        }
      }
    };
    finder(0, 0);
    finder(0, GRID - 7);
    finder(GRID - 7, 0);
    for (let i = 8; i < GRID - 8; i++) {
      g[6][i] = i % 2 === 0;
      g[i][6] = i % 2 === 0;
    }
    return g;
  }, [value]);

  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
      <rect width={size} height={size} fill="white" rx="4" />
      {matrix.map((row, r) =>
        row.map((bit, c) =>
          bit ? (
            <rect
              key={`${r}-${c}`}
              x={off + c * cell}
              y={off + r * cell}
              width={cell - 0.4}
              height={cell - 0.4}
              fill="#090e1a"
            />
          ) : null
        )
      )}
    </svg>
  );
}

// ── Certificate Modal ──────────────────────────────────────────────────────────

function CertificateModal({ reg, event, onClose }: { reg: Registration; event: CollegeEvent; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-sm">
      <div className="w-full max-w-2xl">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-white font-semibold text-sm">Certificate of Participation</h3>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors">
            <X size={15} />
          </button>
        </div>

        <div className="bg-white rounded-2xl overflow-hidden shadow-2xl" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
          <div className="border-[10px] border-double border-amber-600/60 m-4 rounded-xl p-8 text-center">
            {/* Crest */}
            <div className="flex items-center justify-center gap-3 mb-5">
              <div className="h-px flex-1 bg-amber-600/40" />
              <svg width="48" height="48" viewBox="0 0 48 48" className="shrink-0">
                <circle cx="24" cy="24" r="22" fill="none" stroke="#b45309" strokeWidth="1.5" />
                <circle cx="24" cy="24" r="16" fill="none" stroke="#b45309" strokeWidth="0.75" />
                <text x="24" y="30" textAnchor="middle" fontSize="18" fill="#b45309" fontWeight="700">★</text>
              </svg>
              <div className="h-px flex-1 bg-amber-600/40" />
            </div>

            <p className="text-[10px] tracking-[0.35em] uppercase text-amber-700 font-semibold mb-0.5">National Institute of Technology</p>
            <p className="text-[9px] tracking-widest text-gray-400 mb-6">Office of Student Affairs · Est. 1959</p>

            <h1 className="text-4xl text-gray-800 mb-1 font-normal" style={{ fontFamily: "Georgia, 'Times New Roman', serif", letterSpacing: "0.04em" }}>
              Certificate
            </h1>
            <p className="text-[10px] tracking-[0.25em] uppercase text-gray-400 mb-7">of Participation</p>

            <p className="text-gray-500 text-xs mb-3">This is to certify that</p>

            <div className="inline-block border-b-2 border-gray-700 min-w-[260px] mb-1 pb-1">
              <p className="text-2xl text-gray-900 font-semibold" style={{ fontFamily: "Georgia, serif" }}>
                {reg.studentName}
              </p>
            </div>
            <p className="text-[10px] text-gray-400 mb-6">{reg.studentId} &middot; {reg.department} &middot; {reg.year}</p>

            <p className="text-gray-500 text-xs mb-3">has successfully participated in</p>
            <p className="text-lg font-bold text-indigo-700 mb-1 px-8 leading-snug">{event.title}</p>
            <p className="text-xs text-gray-500 mb-1">held on {formatDate(event.date)}</p>
            <p className="text-xs text-gray-400 mb-5">at {event.venue}</p>
            <p className="text-[10px] text-gray-400 mb-8">Organized by {event.organizer}</p>

            <div className="flex justify-between items-end pt-5 border-t border-gray-100">
              <div className="text-center">
                <div className="w-28 border-b border-gray-300 mb-1 mx-auto" />
                <p className="text-[9px] text-gray-400 uppercase tracking-wide">Event Coordinator</p>
              </div>
              <div className="text-center">
                <p className="text-[9px] text-gray-300 mb-0.5">Cert No: {reg.ticketCode}</p>
                <p className="text-[9px] text-gray-300">{new Date(reg.registeredAt).toLocaleDateString("en-IN")}</p>
              </div>
              <div className="text-center">
                <div className="w-28 border-b border-gray-300 mb-1 mx-auto" />
                <p className="text-[9px] text-gray-400 uppercase tracking-wide">Dean of Students</p>
              </div>
            </div>
          </div>
        </div>

        <button
          onClick={() => window.print()}
          className="mt-3 w-full flex items-center justify-center gap-2 bg-indigo-600 hover:bg-indigo-500 text-white py-3 rounded-xl text-sm font-semibold transition-colors"
        >
          <Download size={15} />
          Download / Print Certificate
        </button>
      </div>
    </div>
  );
}

// ── Ticket Modal ───────────────────────────────────────────────────────────────

function TicketModal({ reg, event, onClose }: { reg: Registration; event: CollegeEvent; onClose: () => void }) {
  const cfg = CAT_CFG[event.category];
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4">
      <div className="w-full max-w-xs">
        <div className="flex justify-between items-center mb-3">
          <h3 className="text-white font-semibold text-sm">Event Ticket</h3>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors">
            <X size={15} />
          </button>
        </div>

        <div className="bg-card border border-border rounded-2xl overflow-hidden shadow-2xl">
          {/* Header */}
          <div className="bg-gradient-to-br from-indigo-600 to-indigo-900 p-6 text-center relative">
            <div className="absolute inset-0 opacity-10" style={{ backgroundImage: "radial-gradient(circle at 20% 80%, white 1px, transparent 1px), radial-gradient(circle at 80% 20%, white 1px, transparent 1px)", backgroundSize: "32px 32px" }} />
            <span className={`inline-flex items-center border text-[10px] font-semibold px-2 py-0.5 rounded-full mb-3 ${cfg.bg} ${cfg.color}`}>
              {cfg.label}
            </span>
            <h3 className="text-white font-bold text-base leading-tight mb-1" style={{ fontFamily: "'Bricolage Grotesque', sans-serif" }}>
              {event.title}
            </h3>
            <p className="text-indigo-200 text-xs">{formatDate(event.date)} &middot; {formatTime(event.time)}</p>
          </div>

          {/* Tear line */}
          <div className="relative flex items-center py-0">
            <div className="w-5 h-5 bg-background rounded-full absolute -left-2.5 border border-border" />
            <div className="flex-1 border-t border-dashed border-border/60 mx-5" />
            <div className="w-5 h-5 bg-background rounded-full absolute -right-2.5 border border-border" />
          </div>

          {/* QR + Info */}
          <div className="p-6 text-center">
            <div className="inline-block rounded-xl overflow-hidden shadow-lg mb-4">
              <QRCode value={reg.ticketCode} size={148} />
            </div>
            <p className="font-mono text-xs font-bold text-foreground tracking-widest mb-5 bg-muted px-3 py-1.5 rounded-lg inline-block">
              {reg.ticketCode}
            </p>

            <div className="space-y-2 text-left bg-muted rounded-xl p-4">
              {[
                ["Name", reg.studentName],
                ["ID", reg.studentId],
                ["Venue", event.venue],
                ["Dept.", reg.department],
              ].map(([label, val]) => (
                <div key={label} className="flex justify-between text-xs gap-3">
                  <span className="text-muted-foreground shrink-0">{label}</span>
                  <span className="text-foreground font-medium text-right">{val}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Registration Modal ─────────────────────────────────────────────────────────

function RegistrationModal({
  event,
  onClose,
  onSuccess,
}: {
  event: CollegeEvent;
  onClose: () => void;
  onSuccess: (reg: Registration) => void;
}) {
  const [form, setForm] = useState({
    name: "Arjun Mehta",
    studentId: DEMO_STUDENT_ID,
    email: "arjun.mehta@nit.edu",
    department: "Computer Science",
    year: "3rd Year",
  });
  const [submitted, setSubmitted] = useState(false);
  const [newReg, setNewReg] = useState<Registration | null>(null);

  const handleSubmit = () => {
    const reg: Registration = {
      id: `reg-${Date.now()}`,
      eventId: event.id,
      studentName: form.name,
      studentId: form.studentId,
      email: form.email,
      department: form.department,
      year: form.year,
      registeredAt: new Date().toISOString(),
      ticketCode: genTicketCode(event.id, form.studentId),
    };
    onSuccess(reg);
    setNewReg(reg);
    setSubmitted(true);
  };

  const valid = form.name && form.studentId && form.email;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4">
      <div className="bg-card border border-border rounded-2xl w-full max-w-md shadow-2xl overflow-hidden">
        {/* Image header */}
        <div className="relative h-32 bg-indigo-950 overflow-hidden">
          <img src={event.image} alt={event.title} className="w-full h-full object-cover opacity-40" />
          <div className="absolute inset-0 bg-gradient-to-t from-card/70 to-transparent" />
          <button onClick={onClose} className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/40 hover:bg-black/60 flex items-center justify-center text-white transition-colors">
            <X size={14} />
          </button>
          <div className="absolute bottom-3 left-4">
            <span className={`text-[10px] font-semibold border px-2 py-0.5 rounded-full ${CAT_CFG[event.category].bg} ${CAT_CFG[event.category].color}`}>
              {CAT_CFG[event.category].label}
            </span>
          </div>
        </div>

        <div className="p-6">
          {submitted && newReg ? (
            <div className="text-center py-4">
              <div className="w-14 h-14 bg-emerald-500/10 border border-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Check size={26} className="text-emerald-400" />
              </div>
              <h3 className="font-bold text-foreground text-lg mb-1" style={{ fontFamily: "'Bricolage Grotesque', sans-serif" }}>
                You&apos;re registered!
              </h3>
              <p className="text-muted-foreground text-sm mb-2">Ticket generated successfully.</p>
              <p className="font-mono text-xs text-indigo-400 bg-indigo-500/10 px-3 py-1.5 rounded-lg inline-block mb-5">
                {newReg.ticketCode}
              </p>
              <button
                onClick={onClose}
                className="w-full bg-indigo-600 hover:bg-indigo-500 text-white py-2.5 rounded-xl text-sm font-semibold transition-colors"
              >
                Done — View My Tickets
              </button>
            </div>
          ) : (
            <>
              <h3 className="font-bold text-foreground mb-0.5 leading-snug" style={{ fontFamily: "'Bricolage Grotesque', sans-serif" }}>
                {event.title}
              </h3>
              <p className="text-xs text-muted-foreground mb-5 flex items-center gap-1.5">
                <Calendar size={10} /> {formatDate(event.date)} &middot; {event.venue}
              </p>

              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] text-muted-foreground mb-1 block font-medium">Full Name *</label>
                    <input
                      value={form.name}
                      onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
                      className="w-full bg-background border border-border rounded-xl px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-muted-foreground mb-1 block font-medium">Student ID *</label>
                    <input
                      value={form.studentId}
                      onChange={e => setForm(p => ({ ...p, studentId: e.target.value }))}
                      className="w-full bg-background border border-border rounded-xl px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-[11px] text-muted-foreground mb-1 block font-medium">Email *</label>
                  <input
                    type="email"
                    value={form.email}
                    onChange={e => setForm(p => ({ ...p, email: e.target.value }))}
                    className="w-full bg-background border border-border rounded-xl px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] text-muted-foreground mb-1 block font-medium">Department</label>
                    <input
                      value={form.department}
                      onChange={e => setForm(p => ({ ...p, department: e.target.value }))}
                      className="w-full bg-background border border-border rounded-xl px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] text-muted-foreground mb-1 block font-medium">Year</label>
                    <select
                      value={form.year}
                      onChange={e => setForm(p => ({ ...p, year: e.target.value }))}
                      className="w-full bg-background border border-border rounded-xl px-3 py-2 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                    >
                      {["1st Year", "2nd Year", "3rd Year", "4th Year", "PG"].map(y => (
                        <option key={y}>{y}</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              <button
                onClick={handleSubmit}
                disabled={!valid}
                className="mt-5 w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed text-white py-2.5 rounded-xl text-sm font-semibold transition-colors"
              >
                Register &amp; Generate QR Ticket
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// ── App ────────────────────────────────────────────────────────────────────────

export default function App() {
  const [view, setView] = useState<View>("events");
  const [events, setEvents] = useState<CollegeEvent[]>(INITIAL_EVENTS);
  const [registrations, setRegistrations] = useState<Registration[]>(INITIAL_REGISTRATIONS);
  const [catFilter, setCatFilter] = useState<EventCategory | "all">("all");
  const [search, setSearch] = useState("");
  const [registeringEvent, setRegisteringEvent] = useState<CollegeEvent | null>(null);
  const [viewingTicket, setViewingTicket] = useState<Registration | null>(null);
  const [viewingCert, setViewingCert] = useState<Registration | null>(null);

  // Admin
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminLoginOpen, setAdminLoginOpen] = useState(false);
  const [adminPass, setAdminPass] = useState("");
  const [adminError, setAdminError] = useState("");
  const [adminTab, setAdminTab] = useState<AdminTab>("dashboard");
  const [showEventForm, setShowEventForm] = useState(false);
  const [editingEvent, setEditingEvent] = useState<CollegeEvent | null>(null);
  const [eventForm, setEventForm] = useState<Partial<CollegeEvent>>({
    title: "", category: "tech", date: "", time: "09:00", venue: "",
    description: "", capacity: 100, organizer: "", tags: [], image: "", featured: false,
  });
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const myRegs = useMemo(
    () => registrations.filter(r => r.studentId === DEMO_STUDENT_ID),
    [registrations]
  );

  const filteredEvents = useMemo(() => {
    return events.filter(e => {
      const matchesCat = catFilter === "all" || e.category === catFilter;
      const q = search.toLowerCase();
      const matchesSearch = !q ||
        e.title.toLowerCase().includes(q) ||
        e.organizer.toLowerCase().includes(q) ||
        e.tags.some(t => t.toLowerCase().includes(q));
      return matchesCat && matchesSearch;
    });
  }, [events, catFilter, search]);

  const alreadyRegistered = (eventId: string) =>
    registrations.some(r => r.eventId === eventId && r.studentId === DEMO_STUDENT_ID);

  const handleRegSuccess = (reg: Registration) => {
    setRegistrations(prev => [...prev, reg]);
    setEvents(prev =>
      prev.map(e => e.id === reg.eventId ? { ...e, registeredCount: e.registeredCount + 1 } : e)
    );
  };

  const handleAdminLogin = () => {
    if (adminPass === "admin123") {
      setIsAdmin(true);
      setAdminLoginOpen(false);
      setView("admin");
      setAdminError("");
      setAdminPass("");
    } else {
      setAdminError("Incorrect password. Hint: admin123");
    }
  };

  const handleDeleteEvent = (id: string) => setEvents(prev => prev.filter(e => e.id !== id));

  const openEditEvent = (event: CollegeEvent) => {
    setEditingEvent(event);
    setEventForm({ ...event });
    setShowEventForm(true);
  };

  const handleSaveEvent = () => {
    if (editingEvent) {
      setEvents(prev => prev.map(e =>
        e.id === editingEvent.id ? { ...e, ...eventForm } as CollegeEvent : e
      ));
    } else {
      const newEv: CollegeEvent = {
        ...(eventForm as CollegeEvent),
        id: `evt-${Date.now()}`,
        registeredCount: 0,
        tags: Array.isArray(eventForm.tags) ? eventForm.tags : [],
      };
      setEvents(prev => [...prev, newEv]);
    }
    setShowEventForm(false);
    setEditingEvent(null);
    setEventForm({ title: "", category: "tech", date: "", time: "09:00", venue: "", description: "", capacity: 100, organizer: "", tags: [], image: "", featured: false });
  };

  const ticketEvent = viewingTicket ? events.find(e => e.id === viewingTicket.eventId) : null;
  const certEvent = viewingCert ? events.find(e => e.id === viewingCert.eventId) : null;

  const navItems: { key: View; label: string }[] = [
    { key: "events", label: "Events" },
    { key: "gallery", label: "Gallery" },
    { key: "tickets", label: "My Tickets" },
    { key: "certificates", label: "Certificates" },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>

      {/* ── Navbar ─────────────────────────────────────────────────────── */}
      <header className="sticky top-0 z-40 border-b border-border bg-background/90 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-4">
          {/* Logo */}
          <div className="flex items-center gap-2.5 shrink-0">
            <div className="w-7 h-7 bg-indigo-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-500/20">
              <BookOpen size={14} className="text-white" />
            </div>
            <div className="leading-none">
              <span className="font-bold text-sm text-foreground tracking-tight" style={{ fontFamily: "'Bricolage Grotesque', sans-serif" }}>CampusHub</span>
              <span className="text-muted-foreground text-[10px] block">NIT Event Portal</span>
            </div>
          </div>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-0.5">
            {navItems.map(({ key, label }) => (
              <button
                key={key}
                onClick={() => setView(key)}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                  view === key
                    ? "bg-indigo-600 text-white shadow-sm shadow-indigo-500/20"
                    : "text-muted-foreground hover:text-foreground hover:bg-accent"
                }`}
              >
                {label}
              </button>
            ))}
          </nav>

          {/* Admin controls */}
          <div className="flex items-center gap-2">
            {isAdmin ? (
              <>
                <button
                  onClick={() => setView("admin")}
                  className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                    view === "admin"
                      ? "bg-amber-500 text-black"
                      : "bg-amber-500/10 text-amber-400 border border-amber-500/20 hover:bg-amber-500/20"
                  }`}
                >
                  <Shield size={12} /> Admin Panel
                </button>
                <button
                  onClick={() => { setIsAdmin(false); setView("events"); }}
                  className="p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
                  title="Logout admin"
                >
                  <LogOut size={14} />
                </button>
              </>
            ) : (
              <button
                onClick={() => setAdminLoginOpen(true)}
                className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
              >
                <Lock size={12} /> Admin
              </button>
            )}
            <button
              className="md:hidden p-1.5 rounded-lg text-muted-foreground hover:bg-accent transition-colors"
              onClick={() => setMobileMenuOpen(v => !v)}
            >
              <Menu size={16} />
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-border bg-background px-4 py-3 flex flex-col gap-1">
            {navItems.map(({ key, label }) => (
              <button
                key={key}
                onClick={() => { setView(key); setMobileMenuOpen(false); }}
                className={`px-4 py-2.5 rounded-xl text-sm font-medium text-left transition-colors ${
                  view === key ? "bg-indigo-600 text-white" : "text-muted-foreground hover:bg-accent"
                }`}
              >
                {label}
              </button>
            ))}
            {isAdmin && (
              <button
                onClick={() => { setView("admin"); setMobileMenuOpen(false); }}
                className="px-4 py-2.5 rounded-xl text-sm font-medium text-left text-amber-400 bg-amber-500/10"
              >
                Admin Panel
              </button>
            )}
          </div>
        )}
      </header>

      {/* ── Admin Login Modal ────────────────────────────────────────────── */}
      {adminLoginOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4">
          <div className="bg-card border border-border rounded-2xl p-7 w-full max-w-sm shadow-2xl">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-amber-500/10 border border-amber-500/20 rounded-xl flex items-center justify-center">
                <Shield size={18} className="text-amber-400" />
              </div>
              <div>
                <h3 className="font-bold text-foreground text-sm" style={{ fontFamily: "'Bricolage Grotesque', sans-serif" }}>Admin Access</h3>
                <p className="text-[11px] text-muted-foreground">Password-protected portal</p>
              </div>
            </div>
            <div className="space-y-3">
              <div>
                <label className="text-[11px] text-muted-foreground mb-1 block font-medium">Password</label>
                <input
                  type="password"
                  value={adminPass}
                  onChange={e => setAdminPass(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && handleAdminLogin()}
                  placeholder="Enter admin password"
                  className="w-full bg-background border border-border rounded-xl px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                />
                {adminError && <p className="text-red-400 text-[11px] mt-1.5">{adminError}</p>}
              </div>
              <div className="flex gap-2 pt-1">
                <button
                  onClick={() => { setAdminLoginOpen(false); setAdminPass(""); setAdminError(""); }}
                  className="flex-1 py-2.5 rounded-xl text-sm text-muted-foreground border border-border hover:bg-accent transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAdminLogin}
                  className="flex-1 py-2.5 rounded-xl text-sm font-semibold bg-amber-500 text-black hover:bg-amber-400 transition-colors"
                >
                  Sign In
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── Modals ──────────────────────────────────────────────────────── */}
      {registeringEvent && (
        <RegistrationModal
          event={registeringEvent}
          onClose={() => setRegisteringEvent(null)}
          onSuccess={(reg) => {
            handleRegSuccess(reg);
            setTimeout(() => setRegisteringEvent(null), 3000);
          }}
        />
      )}
      {viewingTicket && ticketEvent && (
        <TicketModal reg={viewingTicket} event={ticketEvent} onClose={() => setViewingTicket(null)} />
      )}
      {viewingCert && certEvent && (
        <CertificateModal reg={viewingCert} event={certEvent} onClose={() => setViewingCert(null)} />
      )}

      {/* ── Main ────────────────────────────────────────────────────────── */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-8">

        {/* ══════════════════════════ EVENTS ══════════════════════════════ */}
        {view === "events" && (
          <div>
            {/* Hero */}
            <div className="relative rounded-2xl overflow-hidden mb-8 bg-indigo-950" style={{ minHeight: 260 }}>
              <img
                src="https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=1400&h=420&fit=crop&auto=format"
                alt="College campus"
                className="absolute inset-0 w-full h-full object-cover opacity-25"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-indigo-950/95 via-indigo-950/70 to-indigo-950/20" />
              <div className="relative z-10 p-8 md:p-12 max-w-2xl">
                <div className="inline-flex items-center gap-2 bg-amber-500/10 border border-amber-500/25 text-amber-400 text-[11px] font-semibold px-3 py-1 rounded-full mb-4">
                  <Star size={10} fill="currentColor" />
                  {events.filter(e => e.featured).length} Featured Events This Month
                </div>
                <h1 className="text-3xl md:text-[42px] font-extrabold text-white mb-3 leading-[1.1]" style={{ fontFamily: "'Bricolage Grotesque', sans-serif" }}>
                  Your Campus.<br />Your Events.
                </h1>
                <p className="text-indigo-200/80 text-sm mb-6 max-w-md leading-relaxed">
                  Discover workshops, fests, sports, and seminars. Register in seconds, get a QR ticket, and show up.
                </p>
                <div className="flex flex-wrap items-center gap-4 text-xs text-indigo-300/70">
                  <span className="flex items-center gap-1.5">
                    <Users size={11} />
                    {events.reduce((a, e) => a + e.registeredCount, 0).toLocaleString()} students registered
                  </span>
                  <span className="opacity-40">·</span>
                  <span className="flex items-center gap-1.5">
                    <Calendar size={11} />
                    {events.length} upcoming events
                  </span>
                </div>
              </div>
            </div>

            {/* Filter Bar */}
            <div className="flex flex-col sm:flex-row gap-3 mb-6">
              <div className="relative flex-1 min-w-0">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <input
                  value={search}
                  onChange={e => setSearch(e.target.value)}
                  placeholder="Search events, tags, organizers..."
                  className="w-full bg-card border border-border rounded-xl pl-9 pr-4 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                />
              </div>
              <div className="flex gap-1.5 flex-wrap">
                {(["all", "tech", "cultural", "sports", "workshop", "seminar", "music"] as const).map(cat => (
                  <button
                    key={cat}
                    onClick={() => setCatFilter(cat)}
                    className={`px-3 py-2 rounded-xl text-[11px] font-semibold capitalize transition-colors ${
                      catFilter === cat
                        ? "bg-indigo-600 text-white shadow-sm shadow-indigo-500/25"
                        : "bg-card border border-border text-muted-foreground hover:text-foreground hover:border-indigo-500/30"
                    }`}
                  >
                    {cat === "all" ? "All" : CAT_CFG[cat].label}
                  </button>
                ))}
              </div>
            </div>

            {/* Event Grid */}
            <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {filteredEvents.map((event, i) => {
                const cfg = CAT_CFG[event.category];
                const pct = Math.round((event.registeredCount / event.capacity) * 100);
                const isFull = pct >= 100;
                const isReg = alreadyRegistered(event.id);
                return (
                  <motion.div
                    key={event.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.04, duration: 0.3 }}
                    className="bg-card border border-border rounded-2xl overflow-hidden group hover:border-indigo-500/30 transition-all hover:shadow-lg hover:shadow-indigo-500/5"
                  >
                    <div className="relative h-44 bg-indigo-950 overflow-hidden">
                      <img
                        src={event.image}
                        alt={event.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-card/70 via-transparent to-transparent" />
                      <div className="absolute top-3 left-3 flex items-center gap-2">
                        <span className={`inline-flex items-center border text-[10px] font-semibold px-2.5 py-0.5 rounded-full ${cfg.bg} ${cfg.color}`}>
                          {cfg.label}
                        </span>
                      </div>
                      {event.featured && (
                        <span className="absolute top-3 right-3 inline-flex items-center gap-1 bg-amber-500 text-black text-[10px] font-bold px-2 py-0.5 rounded-full">
                          <Star size={8} fill="currentColor" /> Featured
                        </span>
                      )}
                    </div>

                    <div className="p-4">
                      <h3 className="font-bold text-foreground text-sm mb-2.5 leading-snug line-clamp-2" style={{ fontFamily: "'Bricolage Grotesque', sans-serif" }}>
                        {event.title}
                      </h3>
                      <div className="space-y-1.5 mb-3.5">
                        <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                          <Calendar size={10} className="shrink-0" />
                          {formatDate(event.date)} &middot; {formatTime(event.time)}
                        </div>
                        <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                          <MapPin size={10} className="shrink-0" />
                          <span className="truncate">{event.venue}</span>
                        </div>
                        <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                          <Users size={10} className="shrink-0" />
                          {event.registeredCount.toLocaleString()} / {event.capacity.toLocaleString()} registered
                        </div>
                      </div>

                      {/* Capacity bar */}
                      <div className="mb-4">
                        <div className="h-1 bg-muted rounded-full overflow-hidden">
                          <div
                            className={`h-full rounded-full transition-all duration-500 ${isFull ? "bg-red-500" : pct > 80 ? "bg-amber-500" : "bg-indigo-500"}`}
                            style={{ width: `${Math.min(pct, 100)}%` }}
                          />
                        </div>
                        <p className="text-[10px] text-muted-foreground mt-1">
                          {isFull ? "Fully booked" : `${(event.capacity - event.registeredCount).toLocaleString()} spots remaining`}
                        </p>
                      </div>

                      <button
                        onClick={() => !isFull && !isReg && setRegisteringEvent(event)}
                        disabled={isFull || isReg}
                        className={`w-full py-2 rounded-xl text-[11px] font-bold transition-all ${
                          isReg
                            ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 cursor-default"
                            : isFull
                            ? "bg-muted/60 text-muted-foreground cursor-not-allowed"
                            : "bg-indigo-600 text-white hover:bg-indigo-500 shadow-sm shadow-indigo-500/20 hover:shadow-indigo-500/30"
                        }`}
                      >
                        {isReg ? "✓ Registered" : isFull ? "Fully Booked" : "Register Now →"}
                      </button>
                    </div>
                  </motion.div>
                );
              })}
            </div>

            {filteredEvents.length === 0 && (
              <div className="text-center py-20 text-muted-foreground">
                <Search size={28} className="mx-auto mb-3 opacity-20" />
                <p className="text-sm">No events match your search.</p>
              </div>
            )}
          </div>
        )}

        {/* ══════════════════════════ GALLERY ═════════════════════════════ */}
        {view === "gallery" && (
          <div>
            <div className="mb-8">
              <h1 className="text-3xl font-extrabold text-foreground mb-1.5" style={{ fontFamily: "'Bricolage Grotesque', sans-serif" }}>
                Event Gallery
              </h1>
              <p className="text-muted-foreground text-sm">Moments from past events and celebrations.</p>
            </div>

            <div className="columns-2 md:columns-3 lg:columns-4 gap-3 [column-fill:_balance]">
              {GALLERY_PHOTOS.map((photo, i) => (
                <motion.div
                  key={photo.id}
                  initial={{ opacity: 0, scale: 0.97 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: i * 0.06 }}
                  className="break-inside-avoid mb-3 bg-card border border-border rounded-xl overflow-hidden group cursor-pointer hover:border-indigo-500/30 transition-all"
                >
                  <div className="relative overflow-hidden bg-indigo-950">
                    <img
                      src={photo.image}
                      alt={photo.caption}
                      className="w-full object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors flex items-center justify-center">
                      <Eye size={18} className="text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </div>
                  <div className="p-3">
                    <p className="text-[11px] font-bold text-foreground">{photo.eventName}</p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">{photo.caption} &middot; {photo.year}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}

        {/* ══════════════════════════ TICKETS ═════════════════════════════ */}
        {view === "tickets" && (
          <div>
            <div className="mb-8">
              <h1 className="text-3xl font-extrabold text-foreground mb-1.5" style={{ fontFamily: "'Bricolage Grotesque', sans-serif" }}>
                My Tickets
              </h1>
              <p className="text-muted-foreground text-sm">
                Showing tickets for <span className="text-foreground font-medium">Arjun Mehta</span> · {DEMO_STUDENT_ID}
              </p>
            </div>

            {myRegs.length === 0 ? (
              <div className="text-center py-24">
                <div className="w-16 h-16 bg-card border border-border rounded-2xl flex items-center justify-center mx-auto mb-5">
                  <QrCode size={28} className="text-muted-foreground/40" />
                </div>
                <p className="text-muted-foreground text-sm mb-5">No tickets yet. Register for an event to get your QR ticket.</p>
                <button
                  onClick={() => setView("events")}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-2.5 rounded-xl text-sm font-semibold transition-colors"
                >
                  Browse Events
                </button>
              </div>
            ) : (
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {myRegs.map((reg, i) => {
                  const event = events.find(e => e.id === reg.eventId);
                  if (!event) return null;
                  const cfg = CAT_CFG[event.category];
                  return (
                    <motion.div
                      key={reg.id}
                      initial={{ opacity: 0, y: 16 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.07 }}
                      className="bg-card border border-border rounded-2xl overflow-hidden hover:border-indigo-500/30 transition-all group"
                    >
                      <div className="relative h-28 bg-indigo-950 overflow-hidden">
                        <img src={event.image} alt={event.title} className="w-full h-full object-cover opacity-50 group-hover:scale-105 transition-transform duration-700" />
                        <div className="absolute inset-0 bg-gradient-to-t from-card/80 to-transparent" />
                        <div className="absolute bottom-3 left-4 right-4">
                          <span className={`text-[10px] font-semibold border px-2 py-0.5 rounded-full ${cfg.bg} ${cfg.color}`}>
                            {cfg.label}
                          </span>
                        </div>
                      </div>

                      <div className="p-4">
                        <h3 className="font-bold text-foreground text-sm leading-snug mb-2 line-clamp-2" style={{ fontFamily: "'Bricolage Grotesque', sans-serif" }}>
                          {event.title}
                        </h3>
                        <div className="space-y-1 mb-4">
                          <p className="text-[11px] text-muted-foreground flex items-center gap-1.5">
                            <Calendar size={10} /> {formatDate(event.date)} &middot; {formatTime(event.time)}
                          </p>
                          <p className="text-[11px] text-muted-foreground flex items-center gap-1.5">
                            <MapPin size={10} /> {event.venue}
                          </p>
                        </div>
                        <div className="bg-muted rounded-xl p-3 mb-3 flex items-center justify-between gap-2">
                          <div>
                            <p className="text-[10px] text-muted-foreground mb-0.5">Ticket Code</p>
                            <p className="font-mono text-[11px] font-bold text-foreground">{reg.ticketCode}</p>
                          </div>
                          <div className="bg-white rounded-lg p-1 shadow-sm">
                            <QRCode value={reg.ticketCode} size={36} />
                          </div>
                        </div>
                        <button
                          onClick={() => setViewingTicket(reg)}
                          className="w-full flex items-center justify-center gap-1.5 bg-indigo-600/10 hover:bg-indigo-600/20 text-indigo-400 border border-indigo-500/20 py-2 rounded-xl text-[11px] font-semibold transition-colors"
                        >
                          <QrCode size={12} /> View Full QR Ticket
                        </button>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ════════════════════════ CERTIFICATES ══════════════════════════ */}
        {view === "certificates" && (
          <div>
            <div className="mb-8">
              <h1 className="text-3xl font-extrabold text-foreground mb-1.5" style={{ fontFamily: "'Bricolage Grotesque', sans-serif" }}>
                Certificates
              </h1>
              <p className="text-muted-foreground text-sm">Download participation certificates for your registered events.</p>
            </div>

            {myRegs.length === 0 ? (
              <div className="text-center py-24">
                <div className="w-16 h-16 bg-card border border-border rounded-2xl flex items-center justify-center mx-auto mb-5">
                  <Award size={28} className="text-muted-foreground/40" />
                </div>
                <p className="text-muted-foreground text-sm mb-5">No certificates yet. Register and attend events to earn certificates.</p>
                <button
                  onClick={() => setView("events")}
                  className="bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-2.5 rounded-xl text-sm font-semibold transition-colors"
                >
                  Browse Events
                </button>
              </div>
            ) : (
              <div className="grid gap-4 sm:grid-cols-2">
                {myRegs.map((reg, i) => {
                  const event = events.find(e => e.id === reg.eventId);
                  if (!event) return null;
                  const cfg = CAT_CFG[event.category];
                  return (
                    <motion.div
                      key={reg.id}
                      initial={{ opacity: 0, y: 16 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: i * 0.07 }}
                      className="bg-card border border-border rounded-2xl p-5 flex gap-4 hover:border-amber-500/25 transition-all group"
                    >
                      <div className="w-12 h-12 bg-amber-500/10 border border-amber-500/20 rounded-xl flex items-center justify-center shrink-0 group-hover:bg-amber-500/15 transition-colors">
                        <Award size={22} className="text-amber-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold text-sm text-foreground leading-snug mb-1 line-clamp-2" style={{ fontFamily: "'Bricolage Grotesque', sans-serif" }}>
                          {event.title}
                        </h3>
                        <p className="text-[11px] text-muted-foreground mb-0.5">{formatDate(event.date)} &middot; {event.venue}</p>
                        <p className="text-[11px] text-muted-foreground mb-3">{reg.studentName} &middot; {reg.studentId}</p>
                        <div className="flex items-center gap-3">
                          <span className={`text-[10px] font-semibold border px-2 py-0.5 rounded-full ${cfg.bg} ${cfg.color}`}>
                            {cfg.label}
                          </span>
                          <button
                            onClick={() => setViewingCert(reg)}
                            className="flex items-center gap-1 text-[11px] text-indigo-400 hover:text-indigo-300 font-semibold transition-colors"
                          >
                            <Download size={11} /> Download Certificate
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ══════════════════════════ ADMIN ═══════════════════════════════ */}
        {view === "admin" && !isAdmin && (
          <div className="text-center py-28">
            <div className="w-16 h-16 bg-card border border-border rounded-2xl flex items-center justify-center mx-auto mb-5">
              <Shield size={28} className="text-muted-foreground/40" />
            </div>
            <p className="text-muted-foreground text-sm mb-5">Admin access required to view this section.</p>
            <button
              onClick={() => setAdminLoginOpen(true)}
              className="bg-amber-500 hover:bg-amber-400 text-black px-6 py-2.5 rounded-xl text-sm font-bold transition-colors"
            >
              Login as Admin
            </button>
          </div>
        )}

        {view === "admin" && isAdmin && (
          <div>
            {/* Admin header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-7">
              <div>
                <div className="flex items-center gap-2 mb-0.5">
                  <Shield size={15} className="text-amber-400" />
                  <h1 className="text-2xl font-extrabold text-foreground" style={{ fontFamily: "'Bricolage Grotesque', sans-serif" }}>
                    Admin Panel
                  </h1>
                </div>
                <p className="text-sm text-muted-foreground">Manage events, registrations, and portal settings.</p>
              </div>
              <div className="flex gap-1.5">
                {(["dashboard", "manage", "registrations"] as AdminTab[]).map(tab => (
                  <button
                    key={tab}
                    onClick={() => setAdminTab(tab)}
                    className={`px-3.5 py-2 rounded-xl text-xs font-semibold capitalize transition-colors ${
                      adminTab === tab
                        ? "bg-amber-500 text-black"
                        : "bg-card border border-border text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
            </div>

            {/* ── Dashboard Tab ── */}
            {adminTab === "dashboard" && (
              <div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                  {[
                    { label: "Total Events", value: events.length, Icon: Calendar, color: "text-indigo-400", bg: "bg-indigo-500/10 border-indigo-500/15" },
                    { label: "Registrations", value: registrations.length, Icon: Users, color: "text-emerald-400", bg: "bg-emerald-500/10 border-emerald-500/15" },
                    { label: "Featured Events", value: events.filter(e => e.featured).length, Icon: Star, color: "text-amber-400", bg: "bg-amber-500/10 border-amber-500/15" },
                    { label: "Total Capacity", value: events.reduce((a, e) => a + e.capacity, 0), Icon: BarChart2, color: "text-purple-400", bg: "bg-purple-500/10 border-purple-500/15" },
                  ].map(({ label, value, Icon, color, bg }) => (
                    <div key={label} className="bg-card border border-border rounded-2xl p-5">
                      <div className={`w-9 h-9 ${bg} border rounded-xl flex items-center justify-center mb-3`}>
                        <Icon size={16} className={color} />
                      </div>
                      <p className="text-2xl font-extrabold text-foreground" style={{ fontFamily: "'Bricolage Grotesque', sans-serif" }}>
                        {value.toLocaleString()}
                      </p>
                      <p className="text-[11px] text-muted-foreground mt-0.5">{label}</p>
                    </div>
                  ))}
                </div>

                <h2 className="font-bold text-foreground mb-4 text-sm" style={{ fontFamily: "'Bricolage Grotesque', sans-serif" }}>
                  Events Fill Rate
                </h2>
                <div className="space-y-2.5">
                  {events.map(event => {
                    const pct = Math.round((event.registeredCount / event.capacity) * 100);
                    const cfg = CAT_CFG[event.category];
                    return (
                      <div key={event.id} className="bg-card border border-border rounded-xl p-4 flex items-center gap-4">
                        <div className="w-9 h-9 rounded-lg overflow-hidden bg-indigo-900 shrink-0">
                          <img src={event.image} alt={event.title} className="w-full h-full object-cover" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-xs font-semibold text-foreground truncate mb-1">{event.title}</p>
                          <div className="flex items-center gap-2">
                            <span className={`text-[9px] font-semibold border px-1.5 py-0 rounded ${cfg.bg} ${cfg.color}`}>{cfg.label}</span>
                            <div className="flex-1 h-1 bg-muted rounded-full overflow-hidden">
                              <div
                                className={`h-full rounded-full ${pct >= 100 ? "bg-red-500" : pct > 80 ? "bg-amber-500" : "bg-indigo-500"}`}
                                style={{ width: `${Math.min(pct, 100)}%` }}
                              />
                            </div>
                            <span className="text-[10px] text-muted-foreground shrink-0">{pct}%</span>
                          </div>
                        </div>
                        <div className="text-right shrink-0">
                          <p className="text-sm font-bold text-foreground">{event.registeredCount}</p>
                          <p className="text-[10px] text-muted-foreground">/ {event.capacity}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* ── Manage Tab ── */}
            {adminTab === "manage" && (
              <div>
                <div className="flex justify-between items-center mb-5">
                  <h2 className="font-bold text-foreground text-sm" style={{ fontFamily: "'Bricolage Grotesque', sans-serif" }}>
                    All Events ({events.length})
                  </h2>
                  <button
                    onClick={() => {
                      setEditingEvent(null);
                      setEventForm({ title: "", category: "tech", date: "", time: "09:00", venue: "", description: "", capacity: 100, organizer: "", tags: [], image: "", featured: false });
                      setShowEventForm(true);
                    }}
                    className="flex items-center gap-1.5 bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-xl text-xs font-semibold transition-colors shadow-sm shadow-indigo-500/20"
                  >
                    <Plus size={13} /> Add Event
                  </button>
                </div>

                {showEventForm && (
                  <div className="bg-card border border-border rounded-2xl p-6 mb-6">
                    <h3 className="font-bold text-foreground text-sm mb-5" style={{ fontFamily: "'Bricolage Grotesque', sans-serif" }}>
                      {editingEvent ? "Edit Event" : "New Event"}
                    </h3>
                    <div className="grid gap-3.5 sm:grid-cols-2">
                      <div className="sm:col-span-2">
                        <label className="text-[11px] text-muted-foreground mb-1 block font-medium">Event Title *</label>
                        <input
                          value={eventForm.title}
                          onChange={e => setEventForm(p => ({ ...p, title: e.target.value }))}
                          placeholder="TechFest 2025 — National Hackathon"
                          className="w-full bg-background border border-border rounded-xl px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] text-muted-foreground mb-1 block font-medium">Category</label>
                        <select
                          value={eventForm.category}
                          onChange={e => setEventForm(p => ({ ...p, category: e.target.value as EventCategory }))}
                          className="w-full bg-background border border-border rounded-xl px-3 py-2.5 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                        >
                          {(Object.keys(CAT_CFG) as EventCategory[]).map(c => (
                            <option key={c} value={c}>{CAT_CFG[c].label}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="text-[11px] text-muted-foreground mb-1 block font-medium">Organizer</label>
                        <input
                          value={eventForm.organizer}
                          onChange={e => setEventForm(p => ({ ...p, organizer: e.target.value }))}
                          placeholder="Computer Science Department"
                          className="w-full bg-background border border-border rounded-xl px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] text-muted-foreground mb-1 block font-medium">Date</label>
                        <input
                          type="date"
                          value={eventForm.date}
                          onChange={e => setEventForm(p => ({ ...p, date: e.target.value }))}
                          className="w-full bg-background border border-border rounded-xl px-3 py-2.5 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] text-muted-foreground mb-1 block font-medium">Time</label>
                        <input
                          type="time"
                          value={eventForm.time}
                          onChange={e => setEventForm(p => ({ ...p, time: e.target.value }))}
                          className="w-full bg-background border border-border rounded-xl px-3 py-2.5 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                        />
                      </div>
                      <div className="sm:col-span-2">
                        <label className="text-[11px] text-muted-foreground mb-1 block font-medium">Venue</label>
                        <input
                          value={eventForm.venue}
                          onChange={e => setEventForm(p => ({ ...p, venue: e.target.value }))}
                          placeholder="Main Auditorium, Block A"
                          className="w-full bg-background border border-border rounded-xl px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] text-muted-foreground mb-1 block font-medium">Capacity</label>
                        <input
                          type="number"
                          value={eventForm.capacity}
                          onChange={e => setEventForm(p => ({ ...p, capacity: parseInt(e.target.value) || 0 }))}
                          className="w-full bg-background border border-border rounded-xl px-3 py-2.5 text-sm text-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] text-muted-foreground mb-1 block font-medium">Tags (comma-separated)</label>
                        <input
                          value={Array.isArray(eventForm.tags) ? eventForm.tags.join(", ") : ""}
                          onChange={e => setEventForm(p => ({ ...p, tags: e.target.value.split(",").map(t => t.trim()).filter(Boolean) }))}
                          placeholder="hackathon, AI, prizes"
                          className="w-full bg-background border border-border rounded-xl px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                        />
                      </div>
                      <div className="sm:col-span-2">
                        <label className="text-[11px] text-muted-foreground mb-1 block font-medium">Description</label>
                        <textarea
                          value={eventForm.description}
                          onChange={e => setEventForm(p => ({ ...p, description: e.target.value }))}
                          rows={3}
                          placeholder="Event description..."
                          className="w-full bg-background border border-border rounded-xl px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary resize-none"
                        />
                      </div>
                      <div className="sm:col-span-2">
                        <label className="text-[11px] text-muted-foreground mb-1 block font-medium">Image URL</label>
                        <input
                          value={eventForm.image}
                          onChange={e => setEventForm(p => ({ ...p, image: e.target.value }))}
                          placeholder="https://images.unsplash.com/photo-..."
                          className="w-full bg-background border border-border rounded-xl px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-primary"
                        />
                      </div>
                      <div className="sm:col-span-2 flex items-center gap-2.5">
                        <input
                          type="checkbox"
                          id="feat"
                          checked={!!eventForm.featured}
                          onChange={e => setEventForm(p => ({ ...p, featured: e.target.checked }))}
                          className="w-4 h-4 accent-amber-500 rounded"
                        />
                        <label htmlFor="feat" className="text-sm text-foreground font-medium">Mark as Featured Event</label>
                      </div>
                    </div>
                    <div className="flex gap-2.5 mt-5">
                      <button
                        onClick={() => { setShowEventForm(false); setEditingEvent(null); }}
                        className="flex-1 py-2.5 border border-border rounded-xl text-sm text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={handleSaveEvent}
                        disabled={!eventForm.title}
                        className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-xl text-sm font-semibold transition-colors"
                      >
                        {editingEvent ? "Save Changes" : "Create Event"}
                      </button>
                    </div>
                  </div>
                )}

                <div className="space-y-2.5">
                  {events.map(event => {
                    const cfg = CAT_CFG[event.category];
                    const pct = Math.round((event.registeredCount / event.capacity) * 100);
                    return (
                      <div key={event.id} className="bg-card border border-border rounded-xl p-4 flex gap-3.5 items-start hover:border-border/60 transition-colors">
                        <div className="w-12 h-12 rounded-xl overflow-hidden bg-indigo-900 shrink-0">
                          <img src={event.image} alt={event.title} className="w-full h-full object-cover" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start gap-2 justify-between">
                            <div className="min-w-0">
                              <p className="text-sm font-bold text-foreground leading-snug truncate">{event.title}</p>
                              <div className="flex items-center gap-2 mt-1 flex-wrap">
                                <span className={`text-[10px] font-semibold border px-1.5 py-0.5 rounded ${cfg.bg} ${cfg.color}`}>{cfg.label}</span>
                                {event.featured && <span className="text-[10px] text-amber-400 font-semibold">★ Featured</span>}
                                <span className="text-[10px] text-muted-foreground">{formatDate(event.date)}</span>
                              </div>
                            </div>
                            <div className="flex gap-0.5 shrink-0">
                              <button
                                onClick={() => openEditEvent(event)}
                                className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-accent transition-colors"
                              >
                                <Edit2 size={13} />
                              </button>
                              <button
                                onClick={() => handleDeleteEvent(event.id)}
                                className="p-2 rounded-lg text-muted-foreground hover:text-red-400 hover:bg-red-500/10 transition-colors"
                              >
                                <Trash2 size={13} />
                              </button>
                            </div>
                          </div>
                          <div className="flex items-center gap-3 mt-2">
                            <div className="flex-1 h-1 bg-muted rounded-full overflow-hidden">
                              <div
                                className={`h-full rounded-full ${pct >= 100 ? "bg-red-500" : pct > 80 ? "bg-amber-500" : "bg-indigo-500"}`}
                                style={{ width: `${Math.min(pct, 100)}%` }}
                              />
                            </div>
                            <span className="text-[10px] text-muted-foreground shrink-0">{event.registeredCount}/{event.capacity}</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* ── Registrations Tab ── */}
            {adminTab === "registrations" && (
              <div>
                <h2 className="font-bold text-foreground text-sm mb-5" style={{ fontFamily: "'Bricolage Grotesque', sans-serif" }}>
                  All Registrations ({registrations.length})
                </h2>
                <div className="bg-card border border-border rounded-2xl overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-border">
                          <th className="text-left px-5 py-3.5 text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">Student</th>
                          <th className="text-left px-5 py-3.5 text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">Event</th>
                          <th className="text-left px-5 py-3.5 text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">Ticket</th>
                          <th className="text-left px-5 py-3.5 text-[11px] font-semibold text-muted-foreground uppercase tracking-wide">Date</th>
                        </tr>
                      </thead>
                      <tbody>
                        {registrations.map((reg, i) => {
                          const event = events.find(e => e.id === reg.eventId);
                          return (
                            <tr
                              key={reg.id}
                              className={`hover:bg-accent/30 transition-colors ${i < registrations.length - 1 ? "border-b border-border/40" : ""}`}
                            >
                              <td className="px-5 py-3.5">
                                <p className="font-semibold text-foreground text-xs">{reg.studentName}</p>
                                <p className="text-[11px] text-muted-foreground">{reg.studentId} &middot; {reg.department}</p>
                              </td>
                              <td className="px-5 py-3.5">
                                <p className="text-foreground text-xs max-w-48 truncate font-medium">{event?.title ?? "Unknown"}</p>
                                <p className="text-[11px] text-muted-foreground">{event ? formatDate(event.date) : ""}</p>
                              </td>
                              <td className="px-5 py-3.5">
                                <span className="font-mono text-[11px] text-foreground bg-muted px-2 py-1 rounded-lg">{reg.ticketCode}</span>
                              </td>
                              <td className="px-5 py-3.5 text-[11px] text-muted-foreground whitespace-nowrap">
                                {new Date(reg.registeredAt).toLocaleDateString("en-IN")}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-border mt-20 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 bg-indigo-600/20 rounded flex items-center justify-center">
              <BookOpen size={10} className="text-indigo-400" />
            </div>
            <p className="text-[11px] text-muted-foreground">CampusHub &middot; National Institute of Technology</p>
          </div>
          <p className="text-[11px] text-muted-foreground">Office of Student Affairs &copy; 2025</p>
        </div>
      </footer>
    </div>
  );
}
